package kr.ac.hansung.deng.model;

/**
 * Created by rowks on 2019-04-04.
 */

public class DroneInfo {

}
