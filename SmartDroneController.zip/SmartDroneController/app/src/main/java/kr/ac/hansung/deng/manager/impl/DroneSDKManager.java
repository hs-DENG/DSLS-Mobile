package kr.ac.hansung.deng.manager.impl;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

import kr.ac.hansung.deng.manager.SDKManager;


public class DroneSDKManager implements SDKManager, Serializable {
    public DroneSDKManager(){}

    public DroneSDKManager(Parcel parcel){
        // field mapping

    }

    @Override
    public void connect() {

    }

    @Override
    public void getVideo() {

    }

    @Override
    public void getCapture() {

    }

    @Override
    public void turnLeft() {

    }

    @Override
    public void turnRight() {

    }

    @Override
    public void up() {

    }

    @Override
    public void down() {

    }

    @Override
    public void right() {

    }

    @Override
    public void left() {

    }

    @Override
    public void forward() {

    }

    @Override
    public void back() {

    }

    @Override
    public void takeOff() {

    }

    @Override
    public void landing() {

    }
}
